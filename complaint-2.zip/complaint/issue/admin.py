from django.contrib import admin
from .models import *
admin.site.register(complaint)
# Register your models here.
